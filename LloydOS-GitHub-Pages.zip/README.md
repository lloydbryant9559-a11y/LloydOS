# LloydOS

Browser/PWA version of LloydOS.

## GitHub Pages

1. Create a GitHub repository named `LloydOS`.
2. Upload the contents of this folder to the repository root.
3. Open **Settings → Pages**.
4. Select **Deploy from a branch**.
5. Select `main` and `/ (root)`.
6. Open the generated HTTPS URL on the Galaxy Tab.
7. Choose **Install** or **Add to Home screen**.

This is a starter shell. Replace `index.html`, `manifest.json`, `sw.js`, and the assets with the full LloydOS files as development continues.
